HOW TO SETUP PROJECT:

- Make sure you have node and npm installed on your computer.
- Open terminal and go to the folder where the project is located.
- Run 'npm install' to install all dependencies.
- After finish installing run 'npm start'.
- Project should automaticly open in your browser (http://localhost:3000/)
